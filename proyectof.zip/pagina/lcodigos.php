<?php

session_start();
include('metodos.php');
$list = new Notas;
$lista = $list->Mostrar();

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Mi libreria</title>
  <link rel="stylesheet" href="dilibreria.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
</head>
<body>
  
<div class="page">
  <div class="pageHeader">
    <div class="title">Archivos</div>
    <div class="userPanel"><span class="username"><?php echo $_SESSION['nombreusuario'] ;?></span><img src="imagenes/icono.png" width="40" height="40"/></div>
  </div>
</div>
<form method="GET">
    <div class="barra">
        <ul>
        <i class="fa fa-home"></i><a href="linicio.php">Inicio</a>
        <a href="lcrear.php">Añadir Codigo</a>
        <a href="lcodigos.php">Mis Codigos</a>
        <a href="close.php">Cerrar Sesion</a>
        </ul>
     </div>
     <div class="section1">
       <div>
         <br>
          <div>
           </div>
        <?php foreach ($lista as $dato){ ?>
            <div class="row">
            <p class="p2">Archivo<?php echo $dato["Id"];?></p>
             <div class="col s4 m2">
               <div class="card blue-grey darken-1">
                  <div class="card-content white-text">
                  <span class="card-title"><?php echo $dato["Titulo"];?></span>
                  </div>
                  <div class="card-action">
                  <a href="eliminarNota.php?id=<?php echo $dato["Id"];?>">Eliminar</a>
                  <a href="pegarNota.php?id=<?php echo $dato["Id"];?>">Editar</a>
                  </div>
                </div>    
              </div>
              <?php } ?>
              </div>
           </div>
  </div>
  </div>
      </form>    
</body>
</html>
