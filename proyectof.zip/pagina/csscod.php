<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>JCode-ProyectoFinal</title>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Cherry+Swash'><link rel="stylesheet" href="dihtml.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body>

<h1 class="titulo">
	<br>	JCode - ProyectoFinal <br></h1>

<nav class="menu1">
	<a class="a1" href="index.php">Inicio</a>
	<a class="a1" href="html.php">HTML</a>
	<a class="a1" href="sql.php">SQL</a>
	<a class="a1" href="css.php">CSS</a>
	<a class="a1" href="login.php" target="blank">Mi Libreria</a>
	<div class="animation start-home"></div>
</nav>

<div class="section1">
<nav class="menu2">
	<a class="a2" href="html.php">Introducción</a>
	<a class="a2" href="htmlcod.php">Sentencias/Codigo</a>
	<a class="a2" href="htmlejem.php">Ejercicios/Ejemplos</a>
</nav>
<h3 class="title">Sintaxis CSS</h3>
<h4 class="text">Una regla CSS consta de un selector y un bloque de declaración. El selector apunta al elemento HTML al que desea aplicar estilo. El bloque de declaración contiene una o más declaraciones separadas por punto y coma. Cada declaración incluye un nombre de propiedad CSS y un valor, separados por dos puntos. Varias declaraciones CSS se separan con punto y coma y los bloques de declaración están rodeados por llaves.</h4>
<img src="imagenes/1.3.png" alt="">
<br>
<img src="imagenes/1.4.png" alt="">
<h3 class="title">Selectores CSS</h3>
<h4 class="text">Los selectores CSS se utilizan para "buscar" (o seleccionar) los elementos HTML que desea aplicar estilo.Podemos dividir los selectores de CSS en cinco categorías:Selectores simples (seleccione elementos según el nombre, la identificación, la clase)Selectores de combinador (seleccione elementos en función de una relación específica entre ellos)Selectores de pseudo-clase (seleccione elementos basados ​​en un cierto estado)Selectores de pseudo-elementos (seleccionar y aplicar estilo a una parte de un elemento)Selectores de atributos (seleccione elementos basados ​​en un atributo o valor de atributo)Esta página explicará los selectores de CSS más básicos.</h4>
<img src="imagenes/1.5.png" alt="">
<h3 class="title">El selector de agrupación CSS</h3>
<h4 class="text">El selector de agrupación selecciona todos los elementos HTML con las mismas definiciones de estilo. Mire el siguiente código CSS (los elementos h1, h2 yp tienen las mismas definiciones de estilo):</h4>
<img src="imagenes/1.6.png" alt="">
<h3 class="title">Todos los selectores simples de CSS</h3>
<img src="imagenes/1.7.png" alt="">
<h3 class="title">Cómo agregar CSS</h3>
<h4 class="text">Cuando un navegador lee una hoja de estilo, formateará el documento HTML de acuerdo con la información de la hoja de estilo.
Tres formas de insertar CSS Hay tres formas de insertar una hoja de estilo:
CSS externo,CSS interno,CSS en línea</h4>
<h3 class="title">CSS externo</h3>
<h4  class="text">Con una hoja de estilo externa, puede cambiar el aspecto de un sitio web completo cambiando solo un archivo.
Cada página HTML debe incluir una referencia al archivo de hoja de estilo externo dentro del elemento <link>, dentro de la sección del encabezado.
</h4>
<img src="imagenes/1.8.png" alt="">
<h4  class="text">Una hoja de estilo externa se puede escribir en cualquier editor de texto y se debe guardar con una extensión .css.
El archivo .css externo no debe contener etiquetas HTML.
Así es como se ve el archivo "mystyle.css":</h4>
<img src="imagenes/1.9.png" alt="">
<h3 class="title">CSS interno</h3>
<h4  class="text">Se puede usar un estilo en línea para aplicar un estilo único a un solo elemento.
Para usar estilos en línea, agregue el atributo de estilo al elemento relevante. El atributo de estilo puede contener cualquier propiedad CSS.</h4>
<img src="imagenes/1.10.png" alt="">

</div>
<p class="p1">
© 2021 Jorge Eduardo Arango  <span>PASCUAL BRAVO</span>
</p>

</body>
</html>