<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>JCode-ProyectoFinal</title>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Cherry+Swash'><link rel="stylesheet" href="dihtml.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body>

<h1 class="titulo">
	<br>	JCode - ProyectoFinal <br></h1>

<nav class="menu1">
	<a class="a1" href="index.php">Inicio</a>
	<a class="a1" href="html.php">HTML</a>
	<a class="a1" href="sql.php">SQL</a>
	<a class="a1" href="css.php">CSS</a>
	<a class="a1" href="login.php" target="blank">Mi Libreria</a>
	<div class="animation start-home"></div>
</nav>

<div class="section1">
<nav class="menu2">
	<a class="a2" href="sql.php">Introducción</a>
	<a class="a2" href="sqlcod.php">Sentencias/Codigo</a>
	<a class="a2" href="sqlejem.php">Ejercicios/Ejemplos</a>
</nav>
<h3 class="title">Introducción a SQL</h3>
<h4 class="text">SQL es un lenguaje estándar para acceder y manipular bases de datos.</h4>
<h3 class="title">¿Qué es SQL?</h3>
<h4 class="text">SQL son las siglas de Structured Query Language
SQL le permite acceder y manipular bases de datos
SQL se convirtió en un estándar del American National Standards Institute (ANSI) en 1986 y de la Organización Internacional de Normalización (ISO) en 1987.</h4>
<h3 class="title">¿Qué puede hacer SQL?</h3>
<h4 class="text">SQL puede ejecutar consultas en una base de datos
SQL puede recuperar datos de una base de datos
SQL puede insertar registros en una base de datos
SQL puede actualizar registros en una base de datos
SQL puede eliminar registros de una base de datos
SQL puede crear nuevas bases de datos
SQL puede crear nuevas tablas en una base de datos
SQL puede crear procedimientos almacenados en una base de datos
SQL puede crear vistas en una base de datos
SQL puede establecer permisos en tablas, procedimientos y vistas</h4>
<h3 class="title">Uso de SQL en su sitio web</h3>
<h4 class="text">Para crear un sitio web que muestre datos de una base de datos, necesitará:

Un programa de base de datos RDBMS (es decir, MS Access, SQL Server, MySQL)
Para utilizar un lenguaje de secuencias de comandos del lado del servidor, como PHP o ASP
Para usar SQL para obtener los datos que desea
Para usar HTML / CSS para diseñar la página
</h4>
<h3 class="title">RDBMS</h3>
<h4 class="text">RDBMS son las siglas de Relational Database Management System.
RDBMS es la base de SQL y de todos los sistemas de bases de datos modernos como MS SQL Server, IBM DB2, Oracle, MySQL y Microsoft Access.
Los datos en RDBMS se almacenan en objetos de base de datos llamados tablas. Una tabla es una colección de entradas de datos relacionados y consta de columnas y filas.
</h4>

</div>
<p class="p1">
© 2021 Jorge Eduardo Arango  <span>PASCUAL BRAVO</span>
</p>
</body>
</html>