<?php

include('metodos.php');
session_start();

?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Mi libreria</title>
  <link rel="stylesheet" href="dilibreria.css">

</head>
<body>
<div class="page">
  <div class="pageHeader">
    <div class="title">Crear</div>
    <div class="userPanel"><span class="username">  <?php echo $_SESSION['nombreusuario'] ;?> </span><img src="imagenes/icono.png" width="40" height="40"/></div>
  </div>
  <div class="main">
    <div class="nav">
      <div class="menu">
        <ul>
          <li> <i class="fa fa-home"></i><a href="linicio.php">Inicio</a></li>
          <li><a href="lcrear.php">Añadir Codigo</a></li>
          <li><a href="lcodigos.php">Mis Codigos</a></li>
          <li><a href="close.php">Cerrar Sesion</a></li>
        </ul>
      </div>
    </div>  
    <form class="form1" method="GET">
    <div class="view">
      <div class="viewHeader">
          <div class="functions">
              <button class="boton" type="submit">Guardar</button>
           </div>
          </div>
              <div><p class="p">Nombre Del Archivo</p><input id="title" type="text" class="nom"  name="title"></div>
              <div><p class="p">Texto</p><textarea id="text" type="text" class="cod"  name="text" rows="15" cols="55"></textarea></div>
        </div>
    </div>
  </form>
</div>
</body>
</html>

<?php 

$listado = new Notas;
$lista = $listado->Guardar();

?>