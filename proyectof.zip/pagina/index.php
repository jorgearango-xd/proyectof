<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>JCode-ProyectoFinal</title>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Cherry+Swash'><link rel="stylesheet" href="./dindex.css">

</head>
<body>

<h1 class="titulo">JCode - ProyectoFinal</h1>

<nav class="menu1">
	<a class="a1" href="index.php">Inicio</a>
	<a class="a1" href="html.php">HTML</a>
	<a class="a1" href="sql.php">SQL</a>
	<a class="a1" href="css.php">CSS</a>
	<a class="a1" href="login.php" target="blank">Mi Libreria</a>
	<div class="animation start-home"></div>
</nav>
<div class="section0">
<div class="section1">
<h2>
Hola, muchas gracias por
<br>
visitar esta pagina!!
</h2>
</div>
<div class="section2">

<h2>
<br>
<br>
En esta pagina podras encontrar la introduccion,
<br>
 codigo base y ejercicios  de: HTML, SQL y CSS,
<br>
 todo esto con imagenes y ejemplos
<br>
  para que sea más facil de comprender;
 <br>
proximamente añadiremos más lenguajes!! 
<br>
<br>
 Además al  registrarte
<br>
 e iniciar sesion en tu cuenta, podras acceder 
<br>
a una libreria para guardar tus propios codigos. 
<br>
<br>
Esperamos te sea de utilidad!!
<br>
<br>
</h2>
</div>
</div>

<p class="p1">
© 2021 Jorge Eduardo Arango  <span>PASCUAL BRAVO</span>
</p>
</body>
</html>

