<?php

session_start();

?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Mi libreria</title>
  <link rel="stylesheet" href="./dilibreria.css">

</head>
<body>
<div class="page">
  <div class="pageHeader">
    <div class="title">Mi Libreria</div>
    <div class="userPanel"><span class="username">
    <?php echo $_SESSION['nombreusuario'] ;?> 
    </span><img src="imagenes/icono.png" width="40" height="40"/></div>
  </div>
  <div class="main">
    <div class="nav">
      <div class="menu">
        <ul>
          <li> <i class="fa fa-home"></i><a href="">Inicio</a></li>
          <li><a href="lcrear.php">Añadir Codigo</a></li>
          <li><a href="lcodigos.php">Mis Codigos</a></li>
          <li><a href="close.php">Cerrar Sesion</a></li>
        </ul>
      </div>
    </div>  
<div>
<img class="img" src="imagenes/unnamed.png" alt=""></div>
</body>
</html>

