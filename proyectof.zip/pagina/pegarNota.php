<?php

session_start();
include('metodos.php');

$id= $_GET['id'];

$list = new Notas;
$lista = $list->Pegar($id); 

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Mi libreria</title>
  <link rel="stylesheet" href="dilibreria.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
</head>
<body>
  
<div class="page">
  <div class="pageHeader">
    <div class="title">Editar</div>
    <div class="userPanel"><span class="username"><?php echo $_SESSION['nombreusuario'] ;?></span><img src="imagenes/icono.png" width="40" height="40"/></div>
  </div>
</div>
<form method="GET">
    <div class="barra">
        <ul>
        <i class="fa fa-home"></i><a href="linicio.php">Inicio</a>
        <a href="lcrear.php">Añadir Codigo</a>
        <a href="lcodigos.php">Mis Codigos</a>
        <a href="close.php">Cerrar Sesion</a>
        </ul>
     </div>
       <div>
         <br>
         <?php foreach ($lista as $dato){ ?>
          <div class="section1">
          <p class="p3">Editar</p>
              <div class="section2">
              <div><p class="p">Id</p><textarea id="id1" type="text" class="nom"  name="id1" rows="2" cols="55" ><?php echo $id; ?></textarea></div>
              <div><button class="bot" type="submit">Confirmar</button></div>
              <div><p class="p">Nombre Del Archivo</p><textarea id="title" type="text" class="nom"  name="title" rows="2" cols="55" ><?php echo $dato["Titulo"];?></textarea></div>
              <div><p class="p">Texto</p><textarea id="text" type="text" class="cod"  name="text" rows="35" cols="55"><?php echo $dato["Texto"];?></textarea></div>
              <div><button class="bot" type="submit">Guardar</button></div>
              </div>
           </div>
           <?php } ?>
           </div>
      </div>
  </div>
      </form>    
</body>
</html>

<?php

$listado = new Notas;
$lista2 = $listado->Editar();
?>