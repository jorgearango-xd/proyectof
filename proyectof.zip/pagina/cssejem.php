<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>JCode-ProyectoFinal</title>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Cherry+Swash'><link rel="stylesheet" href="dihtml.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body>

<h1 class="titulo">
	<br>	JCode - ProyectoFinal <br></h1>

<nav class="menu1">
	<a class="a1" href="index.php">Inicio</a>
	<a class="a1" href="html.php">HTML</a>
	<a class="a1" href="sql.php">SQL</a>
	<a class="a1" href="css.php">CSS</a>
	<a class="a1" href="login.php" target="blank">Mi Libreria</a>
	<div class="animation start-home"></div>
</nav>

<div class="section1">
<nav class="menu2">
	<a class="a2" href="css.php">Introducción</a>
	<a class="a2" href="csscod.php">Sentencias/Codigo</a>
	<a class="a2" href="cssejem.php">Ejercicios/Ejemplos</a>
</nav>

<h3 class="title">Ejemplos</h3>
<h3 class="title">Ejem1:</h3>
<img src="imagenes/1.11.png" alt="">
<h3 class="title">Ejem2:</h3>
<img src="imagenes/1.12.png" alt="">

</div>
<p class="p1">
© 2021 Jorge Eduardo Arango  <span>PASCUAL BRAVO</span>
</p>

</body>
</html>