<?php
    try{

        $mysql = mysqli_connect("localhost", "root", "", "proyecto");

    }catch (Exception $error){

        echo "Error capturado. ".$error->getMessage()."<br>";
    }
?>