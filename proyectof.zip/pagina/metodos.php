<?php

class Notas
{

    function Registrarse()
    {
        error_reporting(0);

        include('mysql/conexion.php'); 

        $nombre = $_GET["name"];
        $correo = $_GET["email"];
        $contraseña1 = $_GET["password"];
        $contraseña2 = $_GET["confirm"];

        if($contraseña1 == $contraseña2 and $nombre != "" and $correo != "" and $contraseña1 != "" and $contraseña2 != "")
        {
            $sql = "INSERT INTO login(nombre, correo, contraseña) VALUES ('$nombre', '$correo', '$contraseña1')";
            $mysql->query($sql);
        }

    }

    function InicioSesion()
    {
        error_reporting(0);

        $correo = $_GET['correo'];
        $contraseña = $_GET['contraseña']; 

        include('mysql/conexion.php'); 
            
        if($correo !="" and $contraseña !="")
        {

            $sql = "SELECT * FROM login WHERE correo='$correo' and contraseña='$contraseña'";

            $resultado=$mysql->query($sql);
            $row = $resultado->fetch_row();

            $a1=$row[0];
            $a2=$row[1];
            $a3=$row[2];

            if($correo==$a2 & $contraseña==$a3)
            {
                session_start();
                $_SESSION['nombreusuario']=$a1;
                header("location: ../pagina/linicio.php");
            }
        }

    }

    function Guardar()
    {
        error_reporting(0);
        
        $titulo = $_GET['title'];
        $texto = $_GET['text'];
        $nombre = $_SESSION['nombreusuario'];

        include('mysql/conexion.php'); 

        if($titulo != "")
        {
  
        $sql = "INSERT INTO archivo(nombre, titulo, texto) VALUES ('$nombre', '$titulo', '$texto')";
        $mysql->query($sql);

          header("location: ../pagina/lcrear.php");
        
        }

    }

    function Mostrar()
    {

        error_reporting(0);
        include('mysql/conexion.php'); 

        $nombre = $_SESSION['nombreusuario'];

        $sql = "SELECT * FROM archivo where Nombre='$nombre'";
        $resultado=$mysql->query($sql);
        return $resultado;

    }

    function Borrar($id)
    {

        error_reporting(0);
        include('mysql/conexion.php'); 

        if($id != "")
        {
            
            $sql = "DELETE FROM archivo WHERE id='".$id."';";
            $resultado=$mysql->query($sql);
            header("location: lcodigos.php");
        }

    }
    
    function Pegar($id)
    {  


        error_reporting(0);
        include('mysql/conexion.php'); 

       
            $sql = "SELECT Titulo, Texto FROM archivo where Id='$id'";
            $resultado=$mysql->query($sql);
            return $resultado;

    }

    function Editar()
    {

 
        error_reporting(0);
        include('mysql/conexion.php'); 

            $id1 = $_GET['id1'];
            $titulo = $_GET['title'];
            $texto = $_GET['text'];
    
            if($id1 != "" and $titulo != "" and $texto != "")
            {

            $sql = "UPDATE archivo SET Titulo='$titulo', Texto='$texto' WHERE Id='$id1'";
            $mysql->query($sql);

              header("location: ../pagina/lcodigos.php");          
            }
    }
}
?>