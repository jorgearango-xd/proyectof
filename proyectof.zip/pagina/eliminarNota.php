<?php
    include('metodos.php');
    $id= $_GET['id'];
    $list = new Notas;
    $list->Borrar($id); 
?>