<?php include('metodos.php');?>

<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">    <link href="login.css" rel="stylesheet" type="text/css">
    <title>Pagina Acceso</title>
</head>
<body>
    <div class="container" id="user-options">
        <button class="btn waves-effect waves-light left" type="submit" name="action" disabled>Iniciar Sesion</button>
        <a class="btn waves-effect waves-light right" href="registro.php">Registrarse</a>
    </div><br><br><br>
    <div class="container" id="register">
      <h4 class="center">Iniciar Sesion</h4><br><br>
        <form class="col s12" method="GET">
          <div class="input-field col s6">
            <i class="material-icons prefix">person</i>
            <input id="correo" type="text" class="validate" name="correo">
            <label for="correo">Usuario</label>
          </div>
          <div class="input-field col s6">
            <i class="material-icons prefix">vpn_key</i>
            <input id="contraseña" type="password" class="validate" name="contraseña">
            <label for="contraseña">Contraseña</label>
          </div>
          <div id="button1"> <button class="btn waves-effect waves-light right" type="submit">Confirmar</button></div>
          <br>
        </form>
    </div>
<br>
    <footer class="page-footer">
        <div class="container">
            © 2021 Jorge Eduardo Arango
            <a class="grey-text text-lighten-4 right" href="">PASCUAL BRAVO</a>
        </div>
    </footer>

</body>
</html>

<?php 

$listado = new Notas;
$lista = $listado->InicioSesion();

?>