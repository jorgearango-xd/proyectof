<?php

include('metodos.php');

?>

<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">    <link href="registro.css" rel="stylesheet" type="text/css">
    <title>Pagina Acceso</title>
</head>
<body>
    <div class="container" id="user-options">
        <a class="btn waves-effect waves-light left" href="login.php">Iniciar Sesion</a>
        <button class="btn waves-effect waves-light right" type="submit" name="action" disabled>Registrarse</button>
    </div><br><br><br>
    <div class="container" id="register">
        <h4 class="center">Registrarse</h4><br><br>
        <div class="row">
            <form class="col s12" method="GET">
              <div class="row">
                <div class="input-field col s6">
                  <i class="material-icons prefix">people</i>
                  <input id="name" type="text" class="validate" name="name">
                  <label for="name">Nombre</label>
                </div>
                <div class="input-field col s6">
                  <i class="material-icons prefix">mail</i>
                  <input id="email" type="tel" class="validate" name="email">
                  <label for="email">Correo electronico</label>
                </div>
              </div>
              <div class="row">
                <div class="input-field col s6">
                  <i class="material-icons prefix">vpn_key</i>
                  <input id="password" type="text" class="validate" name="password">
                  <label for="password">Contraseña</label>
                </div>
                <div class="input-field col s6">
                  <i class="material-icons prefix">vpn_key</i>
                  <input id="confirm" type="tel" class="validate" name="confirm">
                  <label for="confirm">Confirmar Contraseña</label>
                </div>
              </div>
              <div id="button"> <button class="btn waves-effect waves-light right" type="submit">Confirmar</button></div>
             <br>
            </form>
        </div>
    </div>
<br>
    <footer class="page-footer">
        <div class="container">
            © 2021 Jorge Eduardo Arango
            <a class="grey-text text-lighten-4 right" href="">PASCUAL BRAVO</a>
        </div>
    </footer>

</body>
</html>

<?php 

$listado = new Notas;
$lista = $listado->Registrarse();

?>

