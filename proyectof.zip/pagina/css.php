<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>JCode-ProyectoFinal</title>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Cherry+Swash'><link rel="stylesheet" href="dihtml.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body>

<h1 class="titulo">
	<br>	JCode - ProyectoFinal <br></h1>

<nav class="menu1">
	<a class="a1" href="index.php">Inicio</a>
	<a class="a1" href="html.php">HTML</a>
	<a class="a1" href="sql.php">SQL</a>
	<a class="a1" href="css.php">CSS</a>
	<a class="a1" href="login.php" target="blank">Mi Libreria</a>
	<div class="animation start-home"></div>
</nav>

<div class="section1">
<nav class="menu2">
	<a class="a2" href="html.php">Introducción</a>
	<a class="a2" href="htmlcod.php">Sentencias/Codigo</a>
	<a class="a2" href="htmlejem.php">Ejercicios/Ejemplos</a>
</nav>
<h3 class="title">¿Qué es CSS?</h3>
<h4  class="text">CSS son las siglas de Cascading Style Sheets CSS describe cómo se mostrarán los elementos HTML en la pantalla, el papel o en otros medios. CSS ahorra mucho trabajo. Puede controlar el diseño de varias páginas web a la vez Las hojas de estilo externas se almacenan en archivos CSS</h4>
<h3 class="title">Demostración de CSS - Una página HTML - ¡Varios estilos!</h3>
<h4  class="text">Aquí mostraremos una página HTML con cuatro hojas de estilo diferentes. Haga clic en los enlaces "Hoja de estilo 1", "Hoja de estilo 2", "Hoja de estilo 3", "Hoja de estilo 4" para ver los diferentes estilos:</h4>
<img src="imagenes/1.1.png" alt="">
<h3 class="title">¿Por qué utilizar CSS?</h3>
<h4  class="text">CSS se utiliza para definir estilos para sus páginas web, incluido el diseño, el diseño y las variaciones en la visualización para diferentes dispositivos y tamaños de pantalla.</h4>
<img src="imagenes/1.2.png" alt="">
<h3 class="title">¿Qué es CSS?</h3>
<h4  class="text">CSS son las siglas de Cascading Style Sheets CSS describe cómo se mostrarán los elementos HTML en la pantalla, el papel o en otros medios. CSS ahorra mucho trabajo. Puede controlar el diseño de varias páginas web a la vez Las hojas de estilo externas se almacenan en archivos CSS</h4>
<h3 class="title">Demostración de CSS - Una página HTML - ¡Varios estilos!</h3>
<h4  class="text">Aquí mostraremos una página HTML con cuatro hojas de estilo diferentes. Haga clic en los enlaces "Hoja de estilo 1", "Hoja de estilo 2", "Hoja de estilo 3", "Hoja de estilo 4" para ver los diferentes estilos:</h4>
<img src="imagenes/1.1.png" alt="">
<h3 class="title">¿Por qué utilizar CSS?</h3>
<h4  class="text">CSS se utiliza para definir estilos para sus páginas web, incluido el diseño, el diseño y las variaciones en la visualización para diferentes dispositivos y tamaños de pantalla.</h4>
<img src="imagenes/1.2.png" alt="">
</div>
<p class="p1">	
© 2021 Jorge Eduardo Arango  <span>PASCUAL BRAVO</span>
</p>

</body>
</html>